Jaclyn LaMorte
25176344
jlamorte@uci.edu

GAME 2

Ideally the player should feel a sense of accomplishment from figuring out how to defeat the spheres that attempt to attack them after
each restart of the game. They should get frustrated, but want to keep continuing playing in order to defeat the enemies.

In later iterations of my game, I would like to change the player character cube to a tank that can actually aim it's weapon as well as
change the enemy spheres to helicopters that actually drop exploding bombs rather than pellets.